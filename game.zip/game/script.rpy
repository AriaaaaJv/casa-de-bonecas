#DECLARAÇÃO DE PERSONAGENS
define m = Character("Mãe", color="#e8a2a2")
define p = Character("Pai", color="#8b0000")
define senhora = Character("Senhora", color="#a3a3a3")
define atendente = Character("Atendente da Padaria", color="#629e84")
define garota = Character("Você", color="#ffb6c1")

#VARIÁVEIS DE CONTROLE DO ROTEIRO
default tem_papel_ajuda = False
default pegou_cafe = False
default pegou_acucar = False
default pegou_pao = False
default erro_toalha = 0
default minigame_suco_falhou = False

#VARIÁVEIS DE EXPLORAÇÃO DO QUARTO
default olhou_blocos = False
default olhou_urso = False
default olhou_diario = False

#TELA DE OBJETIVO FIXO NO CANTO SUPERIOR ESQUERDO
screen exibir_objetivo(texto):
    frame:
        xalign 0.02
        yalign 0.02
        padding (15, 10)
        background "#000000aa"
        text texto:
            size 20
            color "#ffffff"

#TELA DE NAVEGAÇÃO DO DIÁRIO (BOTÕES ANTERIOR E PRÓXIMO)
screen navegacao_diario(pagina_anterior, pagina_seguinte):
    if pagina_anterior:
        textbutton "< Voltar" action Jump(pagina_anterior):
            xalign 0.1
            yalign 0.95
            text_size 24
            text_color "#ffffff"
            text_outlines [(2, "#000000", 0, 0)]

    #Botão "Avançar" 
    if pagina_seguinte:
        textbutton "Avançar >" action Jump(pagina_seguinte):
            xalign 0.9
            yalign 0.95
            text_size 24
            text_color "#ffffff"
            text_outlines [(2, "#000000", 0, 0)]
            
#TELA DA GAVETA ABERTA COM AS 3 TOALHAS
screen cozinha_suco():
    #Fundo mostrando a gaveta aberta com as toalhas dentro
    add "cozinha_suco.png"

    imagebutton:
        xpos 50 ypos 110
        idle "toalha-azul.png"
        hover "toalha-azul.png"
        action Return("azul")

    imagebutton:
        xpos 650 ypos 110
        idle "toalha-rosa.png"
        hover "toalha-rosa.png"
        action Return("rosa")

    imagebutton:
        xpos 1200 ypos 110
        idle "toalha-verde.png"
        hover "toalha-verde.png"
        action Return("verde")
            
#TELA DO MINIGAME DO SUCO COM LINHA INDICADORA VISUAL
screen minigame_suco_interativo():
    #Variável local que controla o nível do suco (de 0 a 100)
    default nivel = 0
    
    timer 0.04 repeat True action SetScreenVariable("nivel", nivel + 1.2)
    
    add "suco-minigame.png"
    
    #Instrução
    text "Clique em 'PARAR' antes que o suco ultrapasse a linha vermelha!" xalign 0.5 yalign 0.25 size 26 color "#ffffff" outlines [(2, "#000000", 0, 0)]

    #Container agrupando a barra e a linha de limite visual
    fixed:
        xmaximum 450 
        ymaximum 35
        xalign 0.5 
        yalign 0.45

        #Barra visual representando o copo enchendo
        bar:
            value nivel
            range 100
            xfill True
            yfill True
            left_bar "#ff9100" # Cor do suco
            right_bar "#333333" # Fundo vazio do copo

        #Linha vermelha vertical indicando o limite exato (em 75% da largura da barra)
        frame:
            xpos 337
            ypos 0
            xmaximum 4
            ymaximum 35
            background "#ff0000"

    #Botão que o jogador precisa clicar para parar de encher
    textbutton "PARAR DE DESPEJAR" action Return(nivel) xalign 0.5 yalign 0.75 text_size 32 text_color "#ffffff" background "#cc3333" padding (25, 12)

#PONTO DE INÍCIO DO JOGO
label start:
    play music "respira.mp3" volume 2

    scene black with fade
    
    centered "Você julga as vítimas de violência doméstica?"
    
    scene black with fade
    
    centered "Será que mesmo sendo apenas uma criança, você conseguiria sobreviver em uma situação dessas?"
    
    scene black with fade
    
    jump cena2

#CENA 2: O QUARTO DA GAROTA
label cena2:
    scene quarto with dissolve
    play music "CenaQuarto.mp3" volume 0.5
    
    #Exibe o objetivo no canto
    show screen exibir_objetivo("OBJETIVO: Explore todos os objetos do quarto")
    
    show me-normal at center with dissolve
    garota "Preciso ver minhas coisas antes de sair do quarto..."
    hide garota with dissolve

    #Menu
    label menu_quarto:

        #VERIFICAÇÃO: Se já olhou os 3 objetos, a mãe chama 
        if olhou_blocos and olhou_urso and olhou_diario:
            hide screen exibir_objetivo
            m "Filhaaa, por favor vem me ajudar a arrumar a mesa antes do seu pai chegar do trabalho!"
            jump cena3

        menu:
            "Olhar blocos de montar no chão" if not olhou_blocos:
                $ olhou_blocos = True
                play sound "blocoss.mp3"
                show me-triste at center with dissolve
                stop sound
                garota "Humm... Eu costumava brincar mais com eles antes..."
                hide me-triste with dissolve
                jump menu_quarto

            "Pegar urso de pelúcia" if not olhou_urso:
                $ olhou_urso = True
                play sound "peluciaa.mp3"
                show me-normal at center with dissolve
                stop sound
                garota "Esse é o meu urso preferido... Ganhei ele no meu aniversário passado."
                hide me-normal with dissolve
                jump menu_quarto

            "Abrir diário" if not olhou_diario:
                $ olhou_diario = True
                show me-pisca at center with dissolve
                garota "Esse é o meu diário... Será que escrevo algo nele hoje?"
                hide me-pisca with dissolve
                hide screen exibir_objetivo
                jump ler_diario

#LEITURA DO DIÁRIO DA GAROTA COM NAVEGAÇÃO
label ler_diario:

    label pag_capa:
        scene diario1 with dissolve
        play sound "CenaDiario.mp3" 
        call screen navegacao_diario(pagina_anterior=None, pagina_seguinte="pag_2")

    label pag_2:
        scene diario2 with dissolve
        play sound "CenaDiario.mp3" 
        call screen navegacao_diario(pagina_anterior="pag_capa", pagina_seguinte="pag_3")
 
    label pag_3:
        scene diario3 with dissolve
        play sound "CenaDiario.mp3" 
        call screen navegacao_diario(pagina_anterior="pag_2", pagina_seguinte="fim_diario")

    label fim_diario:
        scene quarto with dissolve
        jump menu_quarto
    
    #CENA 3: A COZINHA 
label cena3:

    scene bg_cozinha with dissolve
    play music "CenaCozinha.mp3" volume 0.5
    show screen exibir_objetivo("OBJETIVO: Arrumar a mesa (Toalha e Suco)")
    
    show mae at center with dissolve
    m "Finalmente! Pegue uma toalha limpa na gaveta e sirva o suco nos copos."
    hide mae with dissolve

    label escolha_toalha:
        
        #Chama a screen interativa da gaveta e espera o jogador clicar em uma toalha
        call screen cozinha_suco
        
        #O resultado do clique na toalha vem guardado na variável '_return'
        $ escolha_jogador = _return

        if escolha_jogador == "azul":
            $ erro_toalha += 1
            show mae triste at center with dissolve
            m "Não era essa... Essa tem umas manchas. Escolha a mais limpa!"
            hide mae triste with dissolve
            
            jump escolha_toalha

        elif escolha_jogador == "verde":
            $ erro_toalha += 1
            show mae indecisa at center with dissolve
            m "Já falei pra você escolher a que está limpa, menina! Essa está suja."
            hide mae indecisa with dissolve
                        
            jump escolha_toalha

        elif escolha_jogador == "rosa":
            show mae at center with dissolve
            m "Essa mesmo, é a mais bonita e limpa!"
            
    scene cozinha_toalha_suco with dissolve
    play sound "pano.mp3"
    
    pause 1.0
    stop sound

    #Avança para o minigame do suco
    jump minigame_suco
    
    #MINIGAME DO SUCO INTERATIVO
label minigame_suco:

    scene cozinha_toalha_suco with dissolve
    show screen exibir_objetivo("OBJETIVO: Encha o copo de suco até a linha certa")
    
    show mae at center with dissolve
    m "Agora sirva o suco nos copos com cuidado para não fazer bagunça..."
    hide mae with dissolve

    #Chama a tela interativa e guarda o valor retornado pelo botão na variável _return
    play sound "CenaJarra.mp3"
    call screen minigame_suco_interativo
    $ resultado_nivel = _return
    stop sound

    #Lógica de acerto ou falha baseada em 75% da barra
    if resultado_nivel > 75:
        $ minigame_suco_falhou = True
        "O suco passou da linha e derramou um pouco na mesa!"
        m "Menina desastrada! Olha a bagunça que você fez na mesa!"
    else:
        $ minigame_suco_falhou = False
        "O suco ficou na medida certa, sem derramar."
        m "Obrigada filha, encheu direitinho."

    pause 1.0
    hide screen exibir_objetivo

    #Avança para a chegada do pai 
    jump chegada_pai
    
    #CENA 3: O ALMOÇO 
label chegada_pai:

    scene mesa_almoço with dissolve
    
    show screen exibir_objetivo("OBJETIVO: Almoçar em família")
    
    play sound "pratos.mp3" 
    garota "A mamãe coloca a comida na mesa. O papai chega do trabalho e nos sentamos para comer em silêncio..."
    stop sound
    play music "coraçao.mp3" volume 0.5
    
    pause 1.5

    show pai_bravo at center with dissolve
    p "Esse suco está quente e a comida está horrível! Por que você nunca faz as coisas direito?!"
    hide pai_bravo with dissolve
    
    show me-pisca at center with dissolve
    garota "Aperto os meus olhos com força..."
    hide me-pisca with dissolve
    
    show pai tapa at center with dissolve
    pause 0.5
    hide pai tapa with dissolve

    scene black with fade
    play audio "slap.mp3"
    
    pause 1.0
    
    garota "Abro os olhos devagar... A mamãe está com um machucado novo no rosto e o papai está muito irritado."
    stop music 
    scene mesa_almoço with dissolve
    show mae machucada at center with dissolve
    pause 1.0
    
    scene relogio1 with dissolve
    play sound "CenaRelogio.mp3"
    pause 1.0
    scene relogio2 with dissolve
    pause 1.0
    scene relogio3 with dissolve
    stop sound 
    
    pause 1.0
    scene mesa_apos with dissolve
    play music "CenaCozinha.mp3" volume 0.5
    

    #entrega a lista + pedido de socorro
    show mae machucada at center with dissolve
    m "Filha... por favor, vai no supermercado e compra as coisas da lista, tá?"
    scene lista with dissolve
    "..."
    m "Por favor... também entrega isso pra alguém de confiança."
    scene bilhete with dissolve
    pause 4.0

    hide screen exibir_objetivo

    #Mensagem de reflexão
    scene black with fade
    centered "Em um relacionamento abusivo, o agressor sempre encontrará um motivo para impor controle."
    
    scene black with fade
    centered "Mesmo a vítima fazendo tudo de forma 'perfeita', não impede a violência."
    
    jump cena5_mercado
    
    #CENA 5: O SUPERMERCADO
label cena5_mercado:

    scene mercado with dissolve
    play music "CenaSupermercado.mp3" volume 0.5
    show screen exibir_objetivo("OBJETIVO: Comprar café, açúcar, pão e entregar o bilhete")

    garota "Cheguei ao supermercado. Preciso pegar os itens da lista da mamãe e encontrar alguém de confiança..."

    #Escolha dos corredores
    label hub_corredores:

        #Se já pegou tudo retorna para casa
        if pegou_cafe and pegou_acucar and pegou_pao:
            jump fim_supermercado

        menu:
            "Ir para o Corredor 1 (Prateleira de Café)" if not pegou_cafe:
                jump corredor_cafe

            "Ir para o Corredor 2 (Prateleira de Açúcar)" if not pegou_acucar:
                jump corredor_acucar

            "Ir para a Padaria / Corredor 3" if not pegou_pao:
                jump corredor_padaria

#CORREDOR 1: CAFÉ E A SENHORA
label corredor_cafe:

    scene cafe with dissolve
    show screen exibir_objetivo("OBJETIVO: Pegar o café e encontrar alguém de confiança")

    "Chego ao corredor do café. Há uma senhora conhecida fazendo suas compras por aqui..."

    show idosa_normal at center with dissolve
    senhora "Olá meu amor! Sabe a dona Letícia da lojinha? Acredita que ela tá grávida? Tch tch... nem deve saber quem é o pai... Ah, desculpe, você quer me falar algo?"
    hide idosa_normal with dissolve
    
    #Escolha de entregar ou não o bilhete da mãe
    menu:
        "Entregar o papel de socorro da mamãe para a senhora":
            show idosa_brava at center with dissolve
            senhora "Na minha época isso não era nada! Seu pai é um homem tão trabalhador, só se exaltou... Não precisa de tudo isso, menina!"
            hide idosa_brava with dissolve
            
            show me-triste at center with dissolve
            garota "(Acho que ela não entendia a gravidade do que a mamãe passa... Não posso contar com ela.)"
            hide me-triste with dissolve

        "Dizer: 'Não era nada, só queria saber se a senhora estava bem!'":
            show idosa_normal at center with dissolve
            senhora "Ah, que menina educada! Dê um abraço na sua mãe por mim!"
            hide idosa_normal with dissolve

#COLETA DO CAFÉ
    $ pegou_cafe = True
    hide senhora with dissolve
    
    scene cafe with dissolve
    play sound "pegar_item.mp3"
    "Peguei o pacote de café e coloquei na cesta."
    stop sound

    #Retorna ao menu dos corredores
    jump hub_corredores

#CORREDOR 2: AÇÚCAR
    label corredor_acucar:

    scene açucar with dissolve
    show screen exibir_objetivo("OBJETIVO: Pegar o açúcar")

    "Vou até o corredor do açúcar. Não há ninguém por aqui, apenas as prateleiras silenciosas."

    $ pegou_acucar = True
    play sound "pegar_item.mp3"
    "Peguei o pacote de açúcar e coloquei na cesta."
    stop sound

    jump hub_corredores

#CORREDOR 3: PADARIA
    label corredor_padaria:

    scene padaria with dissolve
    show screen exibir_objetivo("OBJETIVO: Comprar o pão e procurar ajuda")

    show atendente_normal at center with dissolve
    atendente "Olá mocinha, você já está enorme! Como está sua mãe? Éramos tão amigas na escola, espero que esteja bem. Vai querer o pãozinho de sempre?"
    hide atendente_normal with dissolve

    $ pegou_pao = True

    menu:
        "Entregar o bilhete de pedido de socorro da mãe":
            $ tem_papel_ajuda = True
            show atendente_assustada at center with dissolve
            atendente "Meu Deus! Eu não acredito!"
            hide atendente_assustada with dissolve
            
            show atendente_triste at center with dissolve
            atendente "Eu sinto muito por tudo que a sua mãe está passando... ela não merece isso."
            atendente "Olha... na minha faculdade tem uma rede de apoio a mulheres que sofrem violência doméstica. Acho que o nome era Uepa por Elas, ou algo assim... Eu posso te dar o panfleto que deram pra gente na palestra."
            atendente "Eu sei que é difícil, mas eu estou aqui pra ajudar se vocês precisarem."
            atendente "..."
            atendente "Eu sei que você é só uma criança, mas entregando isso pra sua mãe, ela vai conseguir ajuda."
            hide atendente_triste with dissolve
            
            scene panfleto with dissolve
            play sound "pegar_item.mp3"
            "Você recebeu o Panfleto da Uepa por Elas!"
            stop sound
            scene padaria with dissolve
            
        "Apenas comprar o pão (Não entregar o papel)":
            show me-triste at center with dissolve
            garota "Só o pão, por favor."
            hide me-triste with dissolve
                    
            show atendente_pisca at center with dissolve
            atendente "Claro! Aqui está, precisa de mais algo?"
            hide atendente_pisca with dissolve
            play sound "pegar_item.mp3"
                    
            show me-triste at center with dissolve
            stop sound
            garota "Não, obrigada."
            hide me-triste with dissolve
                    
            "Você foi embora sem conseguir pedir ajuda, perdendo a rede de apoio..."

    hide atendente with dissolve
    jump hub_corredores

# FIM DO SUPERMERCADO (QUANDO TODOS OS ITENS FOREM COLETADOS)
label fim_supermercado:
    hide screen exibir_objetivo
    
    scene mercado with dissolve
    "Já peguei tudo o que a mamãe pediu. Agora preciso voltar para casa..."
    
    jump cena6_finais
    return


# CENA 6: FINAIS (BOM OU RUIM)
label cena6_finais:

    scene cozinha_toalha with dissolve
    play music "CenaCozinha.mp3" volume 0.5
    show screen exibir_objetivo("OBJETIVO: Chegar em casa e decidir o que fazer")

    "Chego em casa com a sacola de compras. A mamãe está na cozinha esperando..."
    
    if tem_papel_ajuda:
        menu:
            "Entregar o panfleto da Casa-Abrigo e da Delegacia da Mulher para a mãe":
                hide screen exibir_objetivo
                jump final_bom

            "Pensar: 'Não quero ficar sem o papai, não darei o papel'":
                hide screen exibir_objetivo
                jump final_ruim
    else:
        #Se não pegou o papel - final ruim
        show me-pisca at center with dissolve
        garota "Mãe..."
        hide me-pisca with dissolve
        
        show me-triste at center with dissolve
        garota "Não consegui pedir ajuda... Me desculpa."
        hide me-triste with dissolve
        
        show mae_chorando at center with dissolve
        m "Tudo bem, meu amor... Não é culpa sua."
        hide mae_chorando with dissolve
        
        hide garota
        hide mae
        hide screen exibir_objetivo
        jump final_ruim

# FINAL BOM
label final_bom:

    scene abraço with dissolve
    play music "liminal.mp3" volume 0.5
    "A mamãe lê o papel, chora emocionada e me dá um abraço apertado..."
    pause 2.0

    scene black with fade
    centered "Você conseguiu escapar, mas quantas outras não conseguiram?"

    #notícias reais sobre a violência contra a mulher no Brasil
    scene not1 with dissolve
    pause 2.0
    scene not2 with dissolve
    pause 2.0
    scene not3 with dissolve
    pause 2.0
    scene not4 with dissolve
    pause 2.0
    scene not5 with dissolve
    pause 2.0
    scene not6 with dissolve
    pause 2.0
    scene not7 with dissolve
    pause 2.0
    scene not8 with dissolve
    pause 2.0
    scene not9 with dissolve
    pause 2.0
    scene not10 with dissolve
    pause 2.0
    scene not11 with dissolve
    pause 2.0

    scene black with fade
    centered "Fique alerta a qualquer tipo de manipulação e agressão, seja física ou psicológica, com você ou qualquer outra mulher que você conheça."

    scene black with fade
    centered "Denuncie: \n\n180 — Delegacia da Mulher \n\n190 — Polícia Militar"

    centered "NUNCA SE CALE!"
    
    jump creditos

    return

# FINAL RUIM
label final_ruim:

    scene black with fade
    play music "liminal.mp3" volume 0.5
    centered "Infelizmente, a menina foi mais uma vitíma... a mãe não conseguiu sair dessa situação."

    scene black with fade
    centered "Você não precisa passar pela mesma situação sozinho, procure ajuda, denuncie e não se cale!"
    
    scene black with fade
    centered "Mas será que você ajudaria alguém que você conhece a sair dessa situação? Ou você ficaria calado?"
    
    #notícias reais sobre a violência contra a mulher no Brasil
    scene not1 with dissolve
    pause 2.0
    scene not2 with dissolve
    pause 2.0
    scene not3 with dissolve
    pause 2.0
    scene not4 with dissolve
    pause 2.0
    scene not5 with dissolve
    pause 2.0
    scene not6 with dissolve
    pause 2.0
    scene not7 with dissolve
    pause 2.0
    scene not8 with dissolve
    pause 2.0
    scene not9 with dissolve
    pause 2.0
    scene not10 with dissolve
    pause 2.0
    scene not11 with dissolve
    pause 2.0

    scene black with fade
    centered "Fique alerta a qualquer tipo de manipulação e agressão, seja física ou psicológica, com você ou qualquer outra mulher que você conheça."

    scene black with fade
    centered "Denuncie: \n\n180 — Delegacia da Mulher \n\n190 — Polícia Militar"

    centered "NUNCA SE CALE!"
    
    jump creditos

    #CRÉDITOS
label creditos:

    window hide
    scene black with fade

    centered "{size=30}UNIVERSIDADE DO ESTADO DO PARÁ - UEPA\n{i}Projeto UEPA por elas{/i}{/size}"
    
    scene black with fade

    centered "{size=32}{b}EQUIPE{/b}{/size}\n\n{size=24}Professor: Wandersson Alexandre da Silva Quinto\n\nAntonio Vinicius Silva Conceição\nIgor de Souza Soares da Silva\nJulia Araujo Dias{/size}"

    scene black with fade

    centered "{size=32}{b}FERRAMENTAS UTILIZADAS{/b}{/size}\n\n{size=24}Engine: Ren'Py Visual Novel Engine\nCódigo: VS Code / Python\nArtes e Interface: Ilustração Digital\nÁudios: Freesound, Pixbay e Epidemicsounds{/size}"

    scene black with fade

    centered "{size=30}{b}AGRADECIMENTOS ESPECIAIS{/b}{/size}\n\n{size=22}À Universidade do Estado do Pará (UEPA)\nE a todas as redes de apoio à mulher do Estado do Pará.{/size}"
    scene black with fade
    
    centered "{size=30}{b}Obrigado por jogar!{/b}{/size}\n\n{size=30}"
    scene black with fade
    
    return
        

